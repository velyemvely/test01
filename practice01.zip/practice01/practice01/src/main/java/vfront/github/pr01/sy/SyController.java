package vfront.github.pr01.sy;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@RequestMapping("/sy")
@Controller
public class SyController {

	@Autowired
	private SyService service;
	
	@RequestMapping("/")
	public ModelAndView front() {
		System.out.println("syController");
		
		ModelAndView mav = new ModelAndView("/sy/syHome");
		return mav;
	}
	
//	@RequestMapping("/boardList")
//	public ModelAndView boardList(){
//		
//	}
	
	@RequestMapping("/writingPop")
	public ModelAndView writingPop() {
		
		ModelAndView mav = new ModelAndView("/sy/writingPop");
		return mav;
	}
	
	@RequestMapping("/boardWriting")
	public String boardWriting(SyBoardDTO syBoardDTO) {
		
		int res = service.boardWriting(syBoardDTO);
		return "redirect:/pr01/sy/syHome";
		
		
	}
	
}
