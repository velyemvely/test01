package vfront.github.pr01.sy;

import org.apache.ibatis.type.Alias;

@Alias("syBoardDTO")
public class SyBoardDTO {
	
	private int testBoardNum;
	private String id;
	private String title;
	private String contents;
	private String regdate;
	public int getTestBoardNum() {
		return testBoardNum;
	}
	public void setTestBoardNum(int testBoardNum) {
		this.testBoardNum = testBoardNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	
	
}
