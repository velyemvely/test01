package vfront.github.pr01.sy;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class SyDAO {
	
	@Autowired
	private SqlSessionTemplate SqlSessionTemplate;

	public int boardWriting(SyBoardDTO syBoardDTO) {
		return SqlSessionTemplate.insert("sy_mapper.boardWriting",syBoardDTO);
	}

	public List<SyBoardDTO> boardList() {
		return SqlSessionTemplate.selectList("sy_mapper.boardList");
	}

}
