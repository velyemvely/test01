package vfront.github.pr01.sy;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.swing.plaf.synth.SynthSeparatorUI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@RequestMapping("/sy")
@Controller
public class SyController {

	@Autowired
	private SyService service;
	
//	@RequestMapping("/")
//	public ModelAndView front() {
//		System.out.println("syController");
//		
//		ModelAndView mav = new ModelAndView("/sy/syHome");
//		return mav;
//	}

	@RequestMapping("/boardList")
	public ModelAndView boardList(){
		System.out.println("boardList ����");
		List<SyBoardDTO> boardList = service.boardList();
		for(SyBoardDTO each: boardList) {
			System.out.println("=>" +each.toString());
		}
		ModelAndView mav = new ModelAndView("/sy/syHome");
		mav.addObject("boardList", boardList);
		return mav;
	}
	
	@RequestMapping("/writingPop")
	public ModelAndView writingPop() {
		
		ModelAndView mav = new ModelAndView("/sy/writingPop");
		return mav;
	}
	
	@RequestMapping("/boardWriting")
	public String boardWriting(SyBoardDTO syBoardDTO) {
		
		int res = service.boardWriting(syBoardDTO);
		return "redirect:/pr01/sy/boardList";
		
		
	}
	
}
