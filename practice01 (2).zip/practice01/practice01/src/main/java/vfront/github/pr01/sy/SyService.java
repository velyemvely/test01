package vfront.github.pr01.sy;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

@Service
public class SyService extends DefaultTransactionDefinition{
	
	private TransactionStatus status;
	@Autowired
	private PlatformTransactionManager tx;
	
	@Autowired
	private SyDAO dao;

	public int boardWriting(SyBoardDTO syBoardDTO) {
		status = tx.getTransaction(this);
		int res = dao.boardWriting(syBoardDTO);
		if(res>0) {
			tx.commit(status);
			System.out.println("�Է� ����");
		}else {
			tx.rollback(status);
			System.out.println("�Է� ����");
		}
		return res;
	}

	public List<SyBoardDTO> boardList() {
		
		return dao.boardList();
	}

}
