$("#testB").click(function(){
	alert("you pressed a button!");
});

